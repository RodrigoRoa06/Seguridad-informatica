<?php
include 'prueba.html';
error_reporting(0);
$tipoc=$_POST['tipoc'];
$genero=$_POST['genero'];
$accidente=$_POST['accidente'];
$recargo=$_POST['recargo'];
$per=array('accidente','ninguno');
$precio=0;
$errores='';
if($tipoc=='cast'){
    $precio=2000;
}else{
    if($tipoc=='ciru'){
    $precio=10000;
}else{
    if($tipoc=='cons'){
    $precio=1500;
}else{
    if($tipoc=='che'){
    $precio=1200;}}
}
}
echo $precio;
if($genero=='f'&&$tipoc=='cast'){
    $precio=$precio+$precio*0.1;
}
if($accidente=='true'){
    echo '<h1>Consultas veterinaria</h1>';
}
if(!is_string($recargo)){
    $errores.='<p class="errores">Solo se deben ingresar numeros</p>';
}
if(!in_array($accidente,$per)){
    $errores.='<p class="errores">Debe ingresar accidente</p>';
}
if($recargo>1500){
    $precio=$precio-$precio*0.07;
}
if($errores!=''){
    echo $errores;
}else{
    echo '<h1 class="precio_f">el precio final es:  '.$precio.' </h1>';
}
